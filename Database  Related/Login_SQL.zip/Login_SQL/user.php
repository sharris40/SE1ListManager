<!DOCTYPE html>
<html>
<head>
   <title> Edit Users </title>
   <link href="mystyle.css" rel="stylesheet">
</head>
<body>
<?
include "utility_functions.php";

$sessionid = $_GET["sessionid"];
verify_session($sessionid);

// Interpret the query requirements
$q_userID = $_POST["q_userID"];
$q_pword = $_POST["q_pword"];
$q_fname = $_POST["q_fname"];
$q_lname = $_POST["q_lname"];

// Form the query statement and run it.
$sql = "select userID, pword, fname, lname
  from dbUsers order by userID";
//echo($sql);

$result_array = execute_sql_in_oracle ($sql);
$result = $result_array["flag"];
$cursor = $result_array["cursor"];

if ($result == false){
  display_oracle_error_message($cursor);
  die("Client Query Failed.");
}

// Display the query results
echo "<table border=1>";
echo "<tr> <th>UserID</th> <th>Password</th> <th>Firstname</th> <th>Lastname</th> <th>Update</th> <th>Delete</th></tr>";

// Fetch the result from the cursor one by one
while ($values = oci_fetch_array ($cursor)){
  $userID = $values[0];
  $pword = $values[1];
  $fname = $values[2];
  $lname = $values[3];

  echo("<tr>" . 
    "<td>$userID</td> <th>$pword</th> <td>$fname</td> <td>$lname</td>".
    " <td> <A HREF=\"user_update.php?sessionid=$sessionid&userID=$userID\">Update</A> </td> ".
    " <td> <A HREF=\"user_delete.php?sessionid=$sessionid&userID=$userID\">Delete</A> </td> ".
    "</tr>");
}
oci_free_statement($cursor);

echo "</table>";

echo(" <br />
     <FORM> <INPUT type = \"button\" Value = \"Return\"
    onClick = \"history.go(-1);return true;\" > </FORM>

  <form method=\"post\" action=\"user_add.php?sessionid=$sessionid\">
  <input type=\"submit\" value=\"Add User\">
  </form>
");


?>

</body>
</html>