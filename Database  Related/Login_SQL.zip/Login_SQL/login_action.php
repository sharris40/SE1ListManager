<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="mystyle.css" rel="stylesheet">
</head>
<body>

<?
include "utility_functions.php";

// Get the client id and password and verify them
$userID = $_POST["userID"];
$pword = $_POST["pword"];
$userType = $_POST['userType'];

$sql = "select userID " .
      "from dbUSERS " .
      "where userID='$userID'
        and pword ='$pword'";

$result_array = execute_sql_in_oracle ($sql);
$result = $result_array["flag"];
$cursor = $result_array["cursor"];

if ($result == false){
 display_oracle_error_message($cursor);
 die("Client Query Failed.");
}

if($values = oci_fetch_array ($cursor)){
 oci_free_statement($cursor);

 // found the client
 $userID = $values[0];

 // create a new session for this client
 $sessionid = md5(uniqid(rand()));

 // store the link between the sessionid and the clientid
 // and when the session started in the session table

 $sql = "insert into myclientsession " .
   "(sessionid, userID, sessiondate) " .
   "values ('$sessionid', '$userID', sysdate)";

 $result_array = execute_sql_in_oracle ($sql);
 $result = $result_array["flag"];
 $cursor = $result_array["cursor"];

 if ($result == false){
   display_oracle_error_message($cursor);
   die("Failed to create a new session");
 }
 else {
 $userType = fetch_user_account_type($userID);
 $temp1 = trim($userType[0].$userType[1]);


 switch ($temp1){
     case "S":
         header("Location:student_start.php?sessionid=$sessionid");
         break;
     case "AS":
         header("Location:stadmin_start.php?sessionid=$sessionid");
         break;
     case "A":
         header("Location:admin_start.php?sessionid=$sessionid");
         break;
}

 }
}
else {
 // client username not found
 die ('Login failed.  Click <A href="login.html">here</A> to go back to the login page.');
}
?>