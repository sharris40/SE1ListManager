drop table dbUsers cascade constraints;
drop table myclientsession cascade constraints;
drop table admin cascade constraints;
drop Sequence idseq;

Create Sequence idseq
Start with 0001000
Increment BY 1;

create table dbUsers (
	userID varchar2(20),
	pword varchar2(16) not null,
	usertype char(2) default 'S' not null check (usertype in ('A', 'S', 'AS')),
	fname varchar2(20),
	lname varchar2(20),
	primary key(userID)
);

create table myclientsession (
	sessionid varchar2(32),
	userID varchar2(20),
	sessiondate date,
	primary key(sessionid),
  	foreign key (userID) references dbUSERS (userID)
);

create table admin(
	adminID varchar2(20),
	primary key (adminID),
	foreign key (adminID) references dbUsers(userID)
);

commit;