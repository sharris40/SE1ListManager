<head>
    <title>Student</title>
    <link rel="stylesheet" href="mystyle.css">
</head>
<?
include "utility_functions.php";

$sessionid =$_GET["sessionid"];
$userID = verify_session($sessionid);
$userName = fetch_db_user_name($userID);

// Here we can generate the content of the welcome page
echo("Welcome $userName you are a student!<br />");
echo("Click <A HREF = \"student_info.php?sessionid=$sessionid\">here</A> to view your information.");


echo("This page is under construction");

echo("<br />");
echo("<br />");
echo("Click <A HREF = \"logout_action.php?sessionid=$sessionid\">here</A> to Logout.");
?>