<!DOCTYPE html>
<html>
<head>
   <title> Admin User </title>
   <link href="mystyle.css" rel="stylesheet">
</head>
<body>

<?php
include "utility_functions.php";

$sessionid =$_GET["sessionid"];
$userID = verify_session($sessionid);
$userName = fetch_db_user_name($userID);

// Here we can generate the content of the admin_start page
echo("<br />");
echo("Welcome $userName you are an admin!<br />");
echo("<DL>
        <DT>
           <A HREF=\"user.php?sessionid=$sessionid\">Click to edit Users</A>
        </DT>
      </DL>");
echo("<br />");
echo("<br />");
echo("Click <A HREF = \"logout_action.php?sessionid=$sessionid\">here</A> to Logout.");
?>

</body>
</html>